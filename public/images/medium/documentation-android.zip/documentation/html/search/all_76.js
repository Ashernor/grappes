var searchData=
[
  ['validsalelist',['validSaleList',['../classcom_1_1fidzup_1_1spotinstore_1_1_spot_in_store_s_d_k.html#a9c92c296d9305a989c6636a2132437db',1,'com::fidzup::spotinstore::SpotInStoreSDK']]]
];
