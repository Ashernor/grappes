var searchData=
[
  ['spotinstoresdk',['SpotInStoreSDK',['../classcom_1_1fidzup_1_1spotinstore_1_1_spot_in_store_s_d_k.html',1,'com::fidzup::spotinstore']]]
];
