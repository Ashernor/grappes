var searchData=
[
  ['resume',['resume',['../classcom_1_1fidzup_1_1spotinstore_1_1_spot_in_store_s_d_k.html#a88d83cecfee300d6377146ba18fc50b6',1,'com::fidzup::spotinstore::SpotInStoreSDK']]]
];
