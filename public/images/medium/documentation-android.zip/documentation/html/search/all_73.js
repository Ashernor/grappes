var searchData=
[
  ['salecollectionlist',['saleCollectionList',['../classcom_1_1fidzup_1_1spotinstore_1_1_spot_in_store_s_d_k.html#aaf99189407f8dc99101942b506782d0a',1,'com::fidzup::spotinstore::SpotInStoreSDK']]],
  ['salelist',['saleList',['../classcom_1_1fidzup_1_1spotinstore_1_1_spot_in_store_s_d_k.html#a104438d398c04dead0d4fad61120676a',1,'com::fidzup::spotinstore::SpotInStoreSDK']]],
  ['showcoupon',['showCoupon',['../classcom_1_1fidzup_1_1spotinstore_1_1_spot_in_store_s_d_k.html#ae6c55515a132c3c9bfb87e3d8b360772',1,'com::fidzup::spotinstore::SpotInStoreSDK']]],
  ['showcoupongame',['showCouponGame',['../classcom_1_1fidzup_1_1spotinstore_1_1_spot_in_store_s_d_k.html#a2bedcc8908d9f2d69ac8adb81ac17131',1,'com::fidzup::spotinstore::SpotInStoreSDK']]],
  ['showcoupongameused',['showCouponGameUsed',['../classcom_1_1fidzup_1_1spotinstore_1_1_spot_in_store_s_d_k.html#a3c79173a8a59dad1cf29d7bb403a6946',1,'com::fidzup::spotinstore::SpotInStoreSDK']]],
  ['showmessage',['showMessage',['../classcom_1_1fidzup_1_1spotinstore_1_1_spot_in_store_s_d_k.html#a3e72ca4c92551ed5bed2e58e14b95c41',1,'com::fidzup::spotinstore::SpotInStoreSDK']]],
  ['showsale',['showSale',['../classcom_1_1fidzup_1_1spotinstore_1_1_spot_in_store_s_d_k.html#a9f5709c8f4ed55cbacf6cd4cfc5266e0',1,'com::fidzup::spotinstore::SpotInStoreSDK']]],
  ['showsalescollection',['showSalesCollection',['../classcom_1_1fidzup_1_1spotinstore_1_1_spot_in_store_s_d_k.html#af49ae437d3beea3af9a597c0e361afd6',1,'com::fidzup::spotinstore::SpotInStoreSDK']]],
  ['spotinstoresdk',['SpotInStoreSDK',['../classcom_1_1fidzup_1_1spotinstore_1_1_spot_in_store_s_d_k.html',1,'com::fidzup::spotinstore']]],
  ['start',['start',['../classcom_1_1fidzup_1_1spotinstore_1_1_spot_in_store_s_d_k.html#a7d82a2a5847e39c4a293e89aa291382c',1,'com::fidzup::spotinstore::SpotInStoreSDK']]],
  ['stop',['stop',['../classcom_1_1fidzup_1_1spotinstore_1_1_spot_in_store_s_d_k.html#a27eb23b237518e8f0d3d51bf08f654a6',1,'com::fidzup::spotinstore::SpotInStoreSDK']]]
];
