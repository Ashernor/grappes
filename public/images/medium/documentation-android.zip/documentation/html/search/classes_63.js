var searchData=
[
  ['configuration',['Configuration',['../classcom_1_1fidzup_1_1spotinstore_1_1_configuration.html',1,'com::fidzup::spotinstore']]]
];
