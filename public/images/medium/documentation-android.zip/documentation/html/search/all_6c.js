var searchData=
[
  ['listcoupongames',['listCouponGames',['../classcom_1_1fidzup_1_1spotinstore_1_1_spot_in_store_s_d_k.html#a4fa0fdec5c54fc454c826119b4a4bdd2',1,'com::fidzup::spotinstore::SpotInStoreSDK']]],
  ['listcoupons',['listCoupons',['../classcom_1_1fidzup_1_1spotinstore_1_1_spot_in_store_s_d_k.html#abf87bf912f230df50047eb89391d9c45',1,'com::fidzup::spotinstore::SpotInStoreSDK']]],
  ['listmessages',['listMessages',['../classcom_1_1fidzup_1_1spotinstore_1_1_spot_in_store_s_d_k.html#ac5e4fb2f09905d02e239fd330a337184',1,'com::fidzup::spotinstore::SpotInStoreSDK']]]
];
