var searchData=
[
  ['clearcoupongames',['clearCouponGames',['../classcom_1_1fidzup_1_1spotinstore_1_1_spot_in_store_s_d_k.html#a4c989302d059f42c7fee590db2c0835c',1,'com::fidzup::spotinstore::SpotInStoreSDK']]],
  ['clearcoupons',['clearCoupons',['../classcom_1_1fidzup_1_1spotinstore_1_1_spot_in_store_s_d_k.html#a3430962ce2dc06e321eb492052462730',1,'com::fidzup::spotinstore::SpotInStoreSDK']]],
  ['clearmessages',['clearMessages',['../classcom_1_1fidzup_1_1spotinstore_1_1_spot_in_store_s_d_k.html#aabbc4a81486a36adb471a6d218db2dce',1,'com::fidzup::spotinstore::SpotInStoreSDK']]],
  ['clearsalecollections',['clearSaleCollections',['../classcom_1_1fidzup_1_1spotinstore_1_1_spot_in_store_s_d_k.html#a38a59b4442a96aa1d77d89f5911063b5',1,'com::fidzup::spotinstore::SpotInStoreSDK']]]
];
