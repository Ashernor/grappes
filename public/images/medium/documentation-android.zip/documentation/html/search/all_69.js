var searchData=
[
  ['installation_20page',['Installation page',['../index.html',1,'']]],
  ['init',['init',['../classcom_1_1fidzup_1_1spotinstore_1_1_spot_in_store_s_d_k.html#a67226946ccb6e313a42b306293e37126',1,'com.fidzup.spotinstore.SpotInStoreSDK.init(Context ctx, String appKey, String appSecret)'],['../classcom_1_1fidzup_1_1spotinstore_1_1_spot_in_store_s_d_k.html#a0ea495aa213207fb314de61cffb30d4c',1,'com.fidzup.spotinstore.SpotInStoreSDK.init(Context ctx, String appKey, String appSecret, Intent localNotifIntent)'],['../classcom_1_1fidzup_1_1spotinstore_1_1_spot_in_store_s_d_k.html#ad30c86b18927999f481b6f58e22164b6',1,'com.fidzup.spotinstore.SpotInStoreSDK.init(Context ctx, String appKey, String appSecret, int notificationIcon, Intent localNotifIntent)']]]
];
