var searchData=
[
  ['salecollectionlist',['saleCollectionList',['../classcom_1_1fidzup_1_1spotinstore_1_1_spot_in_store_s_d_k.html#aaf99189407f8dc99101942b506782d0a',1,'com::fidzup::spotinstore::SpotInStoreSDK']]],
  ['salelist',['saleList',['../classcom_1_1fidzup_1_1spotinstore_1_1_spot_in_store_s_d_k.html#a104438d398c04dead0d4fad61120676a',1,'com::fidzup::spotinstore::SpotInStoreSDK']]]
];
